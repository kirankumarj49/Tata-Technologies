// cypress/integration/backend/api.spec.js

const axios = require('axios');

describe('REST API Testing', () => {
  const baseUrl = 'https://reqres.in/api';

  it('GET - List Users', async () => {
    const response = await axios.get(`${baseUrl}/users?page=2`);
    expect(response.status).to.eq(200);
    expect(response.data.data).to.be.an('array');
  });

  it('POST - Create User', async () => {
    const response = await axios.post(`${baseUrl}/users`, {
      name: 'John Doe',
      job: 'Software Developer'
    });
    expect(response.status).to.eq(201);
    expect(response.data).to.have.property('name', 'John Doe');
  });

  it('PUT - Update User', async () => {
    const response = await axios.put(`${baseUrl}/users/2`, {
      name: 'Jane Doe',
      job: 'Software Engineer'
    });
    expect(response.status).to.eq(200);
    expect(response.data).to.have.property('name', 'Jane Doe');
  });

  it('DELETE - Delete User', async () => {
    const response = await axios.delete(`${baseUrl}/users/2`);
    expect(response.status).to.eq(204);
  });
});
