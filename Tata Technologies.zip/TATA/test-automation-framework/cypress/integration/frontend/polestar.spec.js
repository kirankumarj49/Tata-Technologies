// cypress/integration/frontend/polestar.spec.js

describe('Polestar Developer Portal', () => {
    it('should load the homepage', () => {
      cy.visit('https://www.polestar.com/se');
      cy.get('body').should('be.visible');
    });
    // Add more frontend tests here...
  });
  